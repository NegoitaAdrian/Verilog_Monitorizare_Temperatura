						Monitorizare temperatura
							Tema 1


Nume: Negoita Adrian-Gabriel
Grupa: 331AB

Tema proiectului presupune implementarea unui circuit de citire a temperaturii de la mai multi senzori
si afisarea acesteia pe un display, in mod codat.

Conform cerintei, tema a fost impartita in 3 module separate, acestea fiind
unite in modulul de top (temperature_top):

Modulul „ sensors_input ”

Acest modul citeste datele de la senzorii activi,
calculeaza suma temperaturilor acestora, cat si numarul de senzori activi.

Modulul „ division ”

Acest modul realizeaza impartirea cu rest a doua numere,
folosind algoritmul clasic de " Long Division " pe biti.
Algoritmul shifteaza gradual, de la stanga la dreapta, scazand cel mai mare multiplu al deimpartitului
la fiecare pas din divizor. Apoi, multiplii devin cifrele catului, iar diferenta finala este restul.

Modulul „ output_display ”

Acest modul realizeaza aproximarea si codarea temperaturii, corespunzator cerintei. 
Aproximarea temperaturii se face comparand numarul de senzori impartit la 2 cu restul impartirii.

Modulul „ temperature_top ”

Asigura conexiunea dintre module.
